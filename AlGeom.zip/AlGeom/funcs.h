//written by Spitkovka
double AGM(double, double);
