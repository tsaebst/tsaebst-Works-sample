﻿#pragma once
#include <iostream>
#include <cassert>
using namespace std;
#include <cmath>
//сума послідовності
double SeqSum(double x, double eps);
//трібоначі рекурсівне, рекурентне
unsigned long long  int tribonacciRecurrent(int);
unsigned long long  int tribonacciRecursive(int, long long int, long long int, long long int);

struct Matrix3x3 {
    unsigned long long int 
        _11, _12, _13,
        _21, _22, _23,
        _31, _32, _33;
};

Matrix3x3 multiplyM(Matrix3x3 first, Matrix3x3 second);
Matrix3x3 powerM(Matrix3x3 a, int n);
unsigned long long int QuickTribo(int n);

//структура дріб
//template <typename T>
struct Fraction
{
    int m;
    int n;
};

//алгоритм евкліда нсд
int euclidusAlg(int a, int b);


//інваріант дробу
template <typename T>
T FractionInvariation(const T& mn)
{
    //assert(mn.n != 0)
    int m = abs(mn.m);
    int n = abs(mn.n);
    if (m == 0)
    {
        n = m = 0;
        return { m, n };
    }
    int divid = euclidusAlg(m, n);
    m = abs(m / divid);
    n = abs(n / divid);
    return T{ m, n };
}



//оператор виведення дробу
ostream& operator<<(ostream& os, const Fraction& f);

//оператор обернення знаку
template <typename T>
T operator-(const T& mn)  
{
    return T{mn.m* ( - 1),mn.n};
}

//оператор обернення дробу
template <typename T>
T operator~(const T & mn)
{
    return T{ mn.n ,mn.m };
}

//подання дробу в десятковому форматі
double FractionDecimal(const Fraction& mn);




//операція додавання, множення, віднімання і ділення
Fraction operator+(const Fraction& x, const Fraction& y);
Fraction operator*(const Fraction& x, const Fraction& y);
Fraction operator-(const Fraction& x, const Fraction& y);
Fraction operator/(const Fraction& x, const Fraction& y);
//піднесення до степеня
Fraction operator^(const Fraction&, int powerRaised);


//GRAPH
void BuildGraph();
double function(double);
