#include <iostream>
#include <cmath>
#include <cassert>
#include "funcs.h"


int euclidusAlg(int a, int b)
{
    if (a == 0)
    {
        return b;
    }
    else if (a < b)
    {
        return euclidusAlg(b, a);
    }
    else
    {
        if ((a - b) < 0)
        {
            return 1;
        }
        return euclidusAlg(a - b, b);
    }
}


double FractionDecimal(const Fraction& mn)
{
    //assert(mn.n != 0);
    int sign = (mn.n < 0) ^ (mn.m < 0) ? -1 : 1;
    double m = abs(mn.m);
    double n = abs(mn.n);

    if (m == 0)
    {
        return 0.0;
    }
    else if (m < n)
    {
        double dec = (m) / n;
        return sign * dec;
    }
    int integer = 0;
    while (m >= n)
    {
        ++integer;
        m -= n;
    }

    return sign * (integer + (m / n));
}


ostream& operator<<(ostream& os, const Fraction& f)
{
    return os << f.m << '/' << f.n << " = " << FractionDecimal(f);
}

ostream& operator-(ostream& os, const Fraction& f)
{
    return os << (-1)*(f.m) << '/' << f.n;
}




Fraction operator+(const Fraction& x, const Fraction& y)
{
    if (x.n == y.n)
    {
        return { x.m + y.m, x.n };
    }
    int lcm = (x.n * y.n) / euclidusAlg(x.n, y.n);
    int numerator = (x.m * (lcm / x.n)) + (y.m * (lcm / y.n));
    Fraction invariant = FractionInvariation(Fraction{ numerator, lcm });

    if (numerator < 0 || lcm < 0)
    {
        return { -invariant.m, invariant.n };
    }

    return invariant;
}

Fraction operator-(const Fraction& x, const Fraction& y)
{

    return (x + (-y));
}

Fraction operator*(const Fraction& x, const Fraction& y)
{
    Fraction multi = { x.m * y.m, x.n * y.n };
    Fraction invariant = FractionInvariation(multi);
    if (multi.n < 0 || multi.m < 0)
    {
        return { -invariant.m, invariant.n };
    }
    return invariant;
}

Fraction operator/(const Fraction& x, const Fraction& y)
{
    return (x * ~(y));
}


Fraction operator^(const Fraction& x, int power)
{
        if (power == 0) 
        {
        return { 1, 1 };
        }
        const Fraction invX = ~x;
        Fraction frac = x;
        int upower = 1;

        for (int i = 1; i < abs(power); ++i)
        {
            frac = frac * x;
        }

        if (power < 0)
        {
            frac = ~frac;
            if (power % 2 != 0)
            {
                upower = -(1);
            }

        }
        Fraction res = frac * Fraction { 1, 1 * upower };
        return res;
}
