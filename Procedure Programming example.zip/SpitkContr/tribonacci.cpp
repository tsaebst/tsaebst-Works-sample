﻿#include "funcs.h"

//мною був обраний тип long long uint, оскільки значення нашого ряду будуть виключно додатніми. розмір такого типу даних складає 64 байти. тобто максимальне число ~ 2^64-1
unsigned long long  int tribonacciRecurrent(int n)
{
	if ((n == 0) | (n == 1))
	{
		return 0;
	}
	else if ((n == 2) | (n == 3))
	{
		return 1;
	}
	long long int x1 = 0, x2 = 1, x3 = 1, xk;
	for (int k = 4; k <= n; ++k)
	{

		xk = (x1 + x2 + x3);
		x1 = x2;
		x2 = x3;
		x3 = xk;
	}
	return xk;
}

unsigned long long  int tribonacciRecursive(int x, long long int x1, long long int x2 , long long int x3)
{

	if ((x == 1) || (x == 0))
	{
		return x1;
	}
	else if ((x == 2))
	{
		return x2;
	}
	return tribonacciRecursive(x - 1, x2, x3, (x1 + x2 + x3));
}





Matrix3x3 multiplyM(Matrix3x3 first, Matrix3x3 second)
{
    Matrix3x3 m;
    m._11 = first._11 * second._11 + first._12 * second._21 + first._13 * second._31;
    m._12 = first._11 * second._12 + first._12 * second._22 + first._13 * second._32;
    m._13 = first._11 * second._13 + first._12 * second._23 + first._13 * second._33;

    m._21 = first._21 * second._11 + first._22 * second._21 + first._23 * second._31;
    m._22 = first._21 * second._12 + first._22 * second._22 + first._23 * second._32;
    m._23 = first._21 * second._13 + first._22 * second._23 + first._23 * second._33;

    m._31 = first._31 * second._11 + first._32 * second._21 + first._33 * second._31;
    m._32 = first._31 * second._12 + first._32 * second._22 + first._33 * second._32;
    m._33 = first._31 * second._13 + first._32 * second._23 + first._33 * second._33;

    return m;

}
Matrix3x3 powerM(Matrix3x3 matrix, int n)
{
    if (n == 0)
    {
        return Matrix3x3{ 1, 0, 0,
                          0, 1, 0,
                          0, 0, 1 };
    }

    Matrix3x3 SlicedMatrix = powerM(matrix, n / 2);
    if (n % 2 != 0)
    {
        return multiplyM(matrix, multiplyM(SlicedMatrix, SlicedMatrix));
    }
    return multiplyM(SlicedMatrix, SlicedMatrix);
}



unsigned long long int QuickTribo(int n)
{
    Matrix3x3 m1{ 1, 1, 1,
                  1, 0, 0,
                  0, 1, 0 };

    if (n == 0 || n == 1)
    {
        return 0; 
    }
    else if (n == 2 || n == 3)
    {
        return 1;
    }

    Matrix3x3 m2 = powerM(m1, n - 2);
    return m2._11;
}
