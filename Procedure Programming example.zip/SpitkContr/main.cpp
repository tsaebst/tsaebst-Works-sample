﻿

#include <iostream>
using namespace std;
#include <cmath>
#include "funcs.h"

int main()
{
	cout << "Writtem by Spitkovska Vladyslava" << endl;
	cout << "==================================================" << endl;
	// TASK 1    Спростити вираз ~((x << 32) | (x >> 32)),
	unsigned int x = 3;
	cout << ~((x << 32)) << endl; //враховуючи кількість пам'яті, яку займає тип unsigned int(32 bites, to be correct) 
	//побітовий зсув вливо і вправо буде давати початкове значення х. відповідно і однакову інверсію.
	cout << "Bite-relocation of uint32 on 32 bites in any way(inverted): " << ~((x << 32)) << endl;
	//ми також можемо представити result так:
	cout <<"Or just inverted uint32 with the same value: " << ~(x) << endl;
	cout << "==================================================" << endl;
	//TASK 2
	int xtask2 = 20;
	cout << "==================================================" << endl;
	cout <<"Sum of sequence of n elemens (where x = "<< xtask2<<"): " << SeqSum(xtask2, 0.001) << endl;
	cout << "==================================================" << endl;
	// TASK 3       
	int nTribo = 50;
	cout <<"Recurrent tribonacci when n="<< nTribo<< ": " << tribonacciRecurrent(nTribo) << endl;
	cout << "==================================================" << endl;
	//TASK 4                
	cout << "Recursive tribonacci when n=" << nTribo << ": " << tribonacciRecursive(nTribo,0 ,1,1) << endl;
	cout << "==================================================" << endl;
	//TASK 5
	cout << "Quick tribonacci when n=" << nTribo << ": " << QuickTribo(nTribo)<< endl;
	cout << "==================================================" << endl;
	//TASK 6  
	Fraction fraction = { -4, 6 };
	Fraction another = { 3, 7 };
	cout << "Fraction 1:" << fraction << endl;
	cout << "Fraction 2: " << another << endl;
	cout << "==================================================" << endl;
	//cout << euclidusAlg(fraction.m, fraction.n);
	// 
	Fraction res = FractionInvariation(fraction);
	cout << "invatiant for the fraction fraction : " << fraction << " is: "<< res << endl;
	cout << "==================================================" << endl;
	//TASK 7        
	cout << fraction << " in decimal notation: " << FractionDecimal(fraction)<< endl;
	cout << "==================================================" << endl;
	//TASK 8
	// 
	cout << "Sign-changed fraction: " << -(fraction)<< endl;
	cout << "Reversed fraction: " << ~(fraction) << endl;
	cout << "Sum of fractions: " << fraction+another << endl;
	cout << "Product of fractions: " << fraction * another << endl;
	cout << "Difference of fractions: " << fraction-another << endl;
	cout << "Fraction of fractions: " << fraction / another << endl;
	cout << "==================================================" << endl;
	//TASK 9
	int powerTask9 = -3;
	cout << "Fraction "<< fraction <<" to the power of "<< powerTask9 << "(as an irreducable fraction): " << (fraction^powerTask9) << endl;

	//TASK 10
	BuildGraph();
	return 0;
}