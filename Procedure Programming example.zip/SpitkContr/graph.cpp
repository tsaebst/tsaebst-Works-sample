﻿#include <iostream>
#include <cmath>
#include "funcs.h"


double function(double x)
{
	return sin(x);
}


void BuildGraph()
{
	const unsigned int numberOfChunksX = 100, numberOfChunksY = 25;
	const int rangeStartX = 0, rangeEndX = 10, rangeStartY = -1, rangeEndY = 1;
	//крок відносно кількості комірок по х і у
	const double stepX = (rangeEndX - rangeStartX) / double(numberOfChunksX);
	const double stepY = (rangeEndY - rangeStartY) / double (numberOfChunksY);
	cout << "stepX: " << stepX << "; stepY: " << stepY << endl;

	double yValues[numberOfChunksX]{};

	for (int pieceNumber = 0; pieceNumber < numberOfChunksX; pieceNumber++) 
	{
		//cout << "piece: " << stepX * pieceNumber << endl;
		double x = rangeStartX + stepX * pieceNumber;
		//cout << "f(x)" << function(x) << endl;
		yValues[pieceNumber] = function(x);
	}

	for (int chunkNumberY = 0; chunkNumberY < numberOfChunksY; chunkNumberY++)
	{
		for (int chunkNumberX = 0; chunkNumberX < numberOfChunksX; chunkNumberX++) 
{
			const int yValue = (rangeEndY - yValues[chunkNumberX]) / stepY;
			if (yValue == chunkNumberY)
			{
				cout << " ";
			}
			else
			{
				cout << "*"; 
			}
		}

		cout << endl;
	}
}

